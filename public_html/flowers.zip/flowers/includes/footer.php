<footer class="footer">
		<div class="footer-blocks container">
		<div class="footer-block1">
			<h2>МЕНЮ</h2>
			<li><a href="index.php">ГЛАВНАЯ</a></li>
			<li><a href="dostavka.php">ДОСТАВКА</a></li>
			<li><a href="types.php">ТИПЫ</a></li>
			<li><a href="contacts.php">КОНТАКТЫ</a></li>
		</div>
		<div class="footer-block2">
			<h2>РЕЖИМ РАБОТЫ МАГАЗИНА</h2>
			<li>ПН-ПТ 8.00-19.00</li>
			<li>СБ-ВС ВЫХОДНОЙ</li>
		</div>
		</div>
	</footer>