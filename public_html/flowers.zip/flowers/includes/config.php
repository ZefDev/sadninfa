<?php

	$config = array(
		'title' => 'Тестовая панель управления',
		'db' =>  array(
			'server' => 'localhost',
			'username' => 'stsvitan_rooot',
			'password' => 'rootroot',
			'name' => 'stsvitan_test_2'
			 ),
		'constants' => array(
			'path_img' =>'../img/',
			'path_img_flowers' =>'img/flowers/',
			'img_nophoto' => '../img/nophoto.jpg')
	);
?>