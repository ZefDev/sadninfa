<!DOCTYPE HTML>
<head>
   <meta charset="utf-8">
   <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/media.css">
	<link rel="stylesheet" href="libs/owlcarousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="libs/owlcarousel/assets/owl.theme.default.min.css">
	<link href="https://fonts.googleapis.com/css?family=Roboto:700, Nosifer" rel="stylesheet"> 
	<?php
		include_once 'includes\config.php'; 
		include_once 'includes\db.php'; 
		include_once 'includes\loadingMainPage.php'; 
		include_once 'includes\pager.php';
		include_once 'includes\workingWithUser.php';
	?>
   <title>САДЫ НИНФА</title>
</head>
<body>
		
	<header>
		<div class="header-content container">
		<div class="logo wow fadeIn">
			<img src="img/logo3.png" alt="">
		</div>
		<div class="menu wow fadeIn">
			<ul>
				<li><a href="index.php">ГЛАВНАЯ</a></li>
				<li><a href="dostavka.php">ДОСТАВКА</a></li>
				<li><a href="types.php">ТИПЫ</a></li>
				<li><a href="contacts.php">КОНТАКТЫ</a></li>
				<li><a href="#">ОБРАТНЫЙ ЗВОНОК</a></li>
				<li><a href="singIn.php">Войти</a></li>
			</ul>
		</div>
		</div>
		<div class="window container">
			<h1>КРУГЛОСУТОЧНАЯ ДОСТАВКА ЦВЕТОВ КУРЬЕРОМ НА ДОМ</h1>
			<div class="button">
			<a href="#">ПОДРОБНЕЕ</a>
			</div>
		</div>
	</header>
	<section class="main container">
		<div class="new">
			<div class="new-title">
				<h1>НОВИНКИ</h1>
			</div>
			<div class="new-slider" id="new-slider">
				<?php 
					$array = reload_new_slider($connection,$config,true);
				?>
				<div id='new-prev' class='new-prev' >
					<?php 
						echo $array['new_prev'];
					?>
				</div>
				<div id="new-boxes" class="new-boxes wow fadeIn">
					<?php 
						echo $array['new_slider'];
					?>
				</div>
				<div class='new-next' >
					<?php 
						echo $array['new_next'];
					?>
				</div>

			</div>
		</div>
		<div class="popular">
			<div class="new-title">
				<h1>ПОПУЛЯРНЫЕ</h1>
			</div>
			<div class="new-slider" id="popular-slider">
			<div class='new-prev' >
				<img id='popular-next' src='img/left-arrow.png' alt='2'></a>
			</div>
				<div id="new-boxes" class="new-boxes">
					<?php 
						echo reload_populer_slider($connection,$config,true);
					?>
				</div>
				<div class='new-next' >
				<img id='popular-next' src='img/right-arrow.png' alt='2'></a>
				</div>
			</div>
		</div>
	</section>
	
		
	
	<?php 
		require_once 'includes/footer.php';
	?>	
	<script src="js/jquery.min.js"></script>
	<script src="libs/owlcarousel/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>
	<script src="js/script.js"></script>
	<script src="js/scriptForSliders.js"></script>
	<script src="js/wow.min.js"></script>
    </script>

	<script>
	  new WOW().init();
	</script>

	
    

	



</body>
</html>